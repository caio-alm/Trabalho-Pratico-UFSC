#include "pessoa.hpp"

string Pessoa::GetNome() { return m_nome; }
size_t Pessoa::GetIdade() { return m_idade; }
string Pessoa::GetData() { return m_data; }
string Pessoa::GetCpf() { return m_cpf; }
float  Pessoa::GetRenda() { return m_renda; }
